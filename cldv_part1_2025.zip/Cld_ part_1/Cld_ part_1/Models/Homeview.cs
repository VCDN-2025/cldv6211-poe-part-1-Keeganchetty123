﻿namespace Cld__part_1.Models
{
    public class Homeview
    {
    }
}
