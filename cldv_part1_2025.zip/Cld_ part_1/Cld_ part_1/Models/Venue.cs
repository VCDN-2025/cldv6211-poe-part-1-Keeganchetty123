﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace EventEase_NET9.Models
{
    public class Venue
    {
        public int VenueId { get; set; }

        [Required]
        [StringLength(100)]
        public string VenueName { get; set; } = string.Empty;

        [Required]
        [StringLength(150)]
        public string Location { get; set; } = string.Empty;

        [Required]
        public int Capacity { get; set; }

        public string ImageUrl { get; set; } = string.Empty;
    }
}