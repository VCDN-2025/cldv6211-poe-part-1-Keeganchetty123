﻿using System;
using System.ComponentModel.DataAnnotations;

namespace EventEase_NET9.Models
{
    public class Booking
    {
        public int BookingId { get; set; }

        [DataType(DataType.Date)]
        public DateTime BookingDate { get; set; }

        public int VenueId { get; set; }

        public Venue Venue { get; set; } = null!;

        public int EventId { get; set; }

        public Event Event { get; set; } = null!;
    }
}