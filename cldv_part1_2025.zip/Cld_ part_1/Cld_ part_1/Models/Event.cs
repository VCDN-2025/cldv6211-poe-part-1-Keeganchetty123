﻿using System;
using System.Collections.Generic;

namespace EventEase_NET9.Models
{
    public class Event
    {
        public int EventId { get; set; }
        public string EventName { get; set; } = "Annual Tech Expo";
        public DateTime EventDate { get; set; } = DateTime.Now.AddDays(14);
        public string Description { get; set; } = "A large-scale technology exhibition featuring startups, developers, and enterprise solutions.";

        public int VenueId { get; set; }
        public Venue Venue { get; set; } = null!;

        public ICollection<Booking> Bookings { get; set; } = new List<Booking>();
    }
}
